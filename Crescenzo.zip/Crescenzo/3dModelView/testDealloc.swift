import QuartzCore
import SceneKit
import GLTFSceneKit
print("test1")
class MySource: SCNSceneSource {
    override init() {
        super.init()
    }
}
do {
    let source = MySource()
    print("allocated")
}
print("test dealloc")
