import Foundation

let f = URL(fileURLWithPath: "/some/dir/myfolder.obj")
print(f.pathExtension)
