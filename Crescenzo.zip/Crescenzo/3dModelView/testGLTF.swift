import Foundation
import SceneKit
import GLTFSceneKit

let url = URL(fileURLWithPath: "/tmp/foo.glb")
do {
    let source = GLTFSceneSource(url: url)
    print("source created")
    _ = try? source.scene()
}
print("out of scope")
