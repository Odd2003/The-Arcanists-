import re

with open('3DModelViewer.xcodeproj/project.pbxproj', 'r') as f:
    content = f.read()

content = content.replace("GENERATE_INFOPLIST_FILE = YES;", "GENERATE_INFOPLIST_FILE = NO;")

with open('3DModelViewer.xcodeproj/project.pbxproj', 'w') as f:
    f.write(content)
