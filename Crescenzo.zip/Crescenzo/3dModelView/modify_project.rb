require 'xcodeproj'
project = Xcodeproj::Project.open('3DModelViewer.xcodeproj')
target = project.targets.first
target.build_configurations.each do |config|
    config.build_settings['GENERATE_INFOPLIST_FILE'] = 'NO'
    config.build_settings['INFOPLIST_FILE'] = '3DModelViewer/Info.plist'
end
project.save
