import Foundation
import ModelIO
import SceneKit.ModelIO
let ext = MDLAsset.canImportFileExtension("glb")
print("glb supported: \(ext)")
