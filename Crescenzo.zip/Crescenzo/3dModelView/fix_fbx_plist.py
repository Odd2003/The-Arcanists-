import sys
import xml.etree.ElementTree as ET

def main():
    tree = ET.parse('/Users/crescenzo/Desktop/3DModelViewer/CustomInfo.plist')
    root = tree.getroot()
    # Find UTImportedTypeDeclarations array
    dict_el = root.find('dict')
    
    # We want to add FBX
    # <dict>
    #     <key>UTTypeIdentifier</key>
    #     <string>com.autodesk.fbx</string>
    #     <key>UTTypeConformsTo</key>
    #     <array><string>public.data</string></array>
    #     <key>UTTypeTagSpecification</key>
    #     <dict>
    #         <key>public.filename-extension</key>
    #         <array><string>fbx</string></array>
    #     </dict>
    #     <key>UTTypeDescription</key>
    #     <string>FBX 3D Model</string>
    # </dict>
    
    print("Will modify CustomInfo.plist")

if __name__ == '__main__':
    main()
