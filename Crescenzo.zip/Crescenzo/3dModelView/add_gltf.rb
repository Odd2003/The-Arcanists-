require 'rubygems'
require 'xcodeproj'

project = Xcodeproj::Project.open('3DModelViewer.xcodeproj')
target = project.targets.first

puts "Adding package reference..."
pkg = project.new(Xcodeproj::Project::Object::XCRemoteSwiftPackageReference)
pkg.repositoryURL = "https://github.com/magicien/GLTFSceneKit.git"
pkg.requirement = {
  "kind" => "upToNextMajorVersion",
  "minimumVersion" => "0.4.1"
}
project.root_object.package_references << pkg

puts "Adding product dependency..."
ref = project.new(Xcodeproj::Project::Object::XCSwiftPackageProductDependency)
ref.package = pkg
ref.product_name = "GLTFSceneKit"
target.package_product_dependencies << ref

puts "Adding to Frameworks build phase..."
build_phase = target.frameworks_build_phase
build_file = project.new(Xcodeproj::Project::Object::PBXBuildFile)
build_file.product_ref = ref
build_phase.files << build_file

project.save
puts "Saved."
