import Foundation
import SceneKit

/// Lightweight value type holding parsed metadata about a loaded 3D model.
struct ModelMetadata {
    var filename: String
    var format: String
    var vertexCount: Int = 0
    var triangleCount: Int = 0
    var materialCount: Int = 0
    var boundingBoxDimensions: SCNVector3 = SCNVector3Zero

    // MARK: - Formatted Accessors

    var formattedVertexCount: String {
        Self.formatter.string(from: NSNumber(value: vertexCount)) ?? "\(vertexCount)"
    }

    var formattedTriangleCount: String {
        Self.formatter.string(from: NSNumber(value: triangleCount)) ?? "\(triangleCount)"
    }

    var formattedDimensions: String {
        String(format: "%.2f × %.2f × %.2f",
               boundingBoxDimensions.x,
               boundingBoxDimensions.y,
               boundingBoxDimensions.z)
    }

    private static let formatter: NumberFormatter = {
        let f = NumberFormatter()
        f.numberStyle = .decimal
        f.groupingSeparator = ","
        return f
    }()
}
