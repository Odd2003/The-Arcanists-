import Foundation
import SceneKit
import Combine
import UniformTypeIdentifiers
import ModelIO
import SceneKit.ModelIO

// MARK: - Supported Types

extension UTType {
    static let obj = UTType("public.geometry-definition-format")
        ?? UTType(importedAs: "public.geometry-definition-format", conformingTo: .data)

    /// Allow selecting any file or folder so users can pick OBJ bundles from Blender exports.
    static let supported3DModels: [UTType] = [.item, .folder]
}

// MARK: - ModelLoader

@MainActor
final class ModelLoader: ObservableObject {

    @Published var isLoading = false
    @Published var currentScene: SCNScene?
    @Published var metadata: ModelMetadata?
    @Published var errorMessage: String?

    private let sandboxDir: URL =
        FileManager.default.temporaryDirectory.appendingPathComponent("ModelStaging", isDirectory: true)

    init() {
        try? FileManager.default.createDirectory(at: sandboxDir, withIntermediateDirectories: true)
    }

    // MARK: - Public API

    func loadModel(from pickerURLs: [URL]) {
        guard !pickerURLs.isEmpty else { return }
        isLoading = true
        errorMessage = nil

        Task.detached(priority: .userInitiated) { [sandboxDir] in
            do {
                // ── 1. Clean staging area and create unique subfolder for this load ────────────────────────────────
                Self.clearDirectory(sandboxDir)
                let uniqueLoadDir = sandboxDir.appendingPathComponent(UUID().uuidString, isDirectory: true)
                try? FileManager.default.createDirectory(at: uniqueLoadDir, withIntermediateDirectories: true)

                // ── 2. Acquire security-scoped access ─────────────────────
                var accessedURLs: [URL] = []
                for url in pickerURLs where url.startAccessingSecurityScopedResource() {
                    accessedURLs.append(url)
                }
                defer { accessedURLs.forEach { $0.stopAccessingSecurityScopedResource() } }

                // ── 3. Copy everything into the sandbox ───────────────────
                var objFileURL: URL?
                var displayName = "Model"

                for pickerURL in pickerURLs {
                    let dest = uniqueLoadDir.appendingPathComponent(pickerURL.lastPathComponent)
                    if FileManager.default.fileExists(atPath: dest.path) {
                        try? FileManager.default.removeItem(at: dest)
                    }
                    try FileManager.default.copyItem(at: pickerURL, to: dest)

                    // Search for OBJ inside what we just copied
                    var isDir: ObjCBool = false
                    _ = FileManager.default.fileExists(atPath: dest.path, isDirectory: &isDir)

                    if isDir.boolValue {
                        Self.findOBJ(in: dest, result: &objFileURL, displayName: &displayName)
                    } else if dest.pathExtension.lowercased() == "obj" && objFileURL == nil {
                        objFileURL = dest
                        displayName = dest.lastPathComponent
                    }
                }

                // ── 3b. Copy sibling files the user didn't explicitly pick ──
                //     (best-effort — covers MTL + textures next to the OBJ)
                Self.copySiblingAssets(from: pickerURLs, into: uniqueLoadDir, accessedURLs: &accessedURLs)

                guard let finalOBJ = objFileURL else {
                    throw ModelLoaderError.noOBJFound
                }

                let objDirectory = finalOBJ.deletingLastPathComponent()

                // ── 4. Load with ModelIO ──────────────────────────────────
                let asset = MDLAsset(url: finalOBJ)
                asset.loadTextures()

                var scene: SCNScene? = SCNScene(mdlAsset: asset)

                // Fallback to SceneKit's built-in OBJ loader
                if scene == nil || (scene?.rootNode.childNodes.isEmpty ?? true) {
                    scene = try? SCNScene(url: finalOBJ, options: [
                        .assetDirectoryURLs : [objDirectory],
                        .createNormalsIfAbsent : true,
                        .checkConsistency : true,
                        .flattenScene : false
                    ])
                }

                guard let loadedScene = scene else {
                    throw ModelLoaderError.loadFailed
                }

                // ── 5. (Textures disabled as requested) ─────────────────────────
                await MainActor.run {
                    // TextureResolver.resolve(in: loadedScene,
                    //                        searchDirectories: [objDirectory, sandboxDir])

                    // Strip any texture properties from materials to prevent "white thingy" render error
                    loadedScene.rootNode.enumerateChildNodes { node, _ in
                        guard let geometry = node.geometry else { return }
                        for material in geometry.materials {
                            // Ensure materials are treated uniquely by SceneKit so they aren't cached across models
                            if let originalName = material.name {
                                material.name = originalName + "-" + UUID().uuidString
                            } else {
                                material.name = UUID().uuidString
                            }
                            
                            material.diffuse.contents = material.diffuse.contents as? UIColor ?? UIColor.lightGray
                            material.emission.contents = UIColor.black
                            material.ambient.contents = UIColor.black
                            material.specular.contents = material.specular.contents as? UIColor ?? UIColor.white
                            material.normal.contents = nil
                            material.metalness.contents = nil
                            material.roughness.contents = nil
                        }
                    }

                    // ── 6. Fix Blender material quirks ────────────────────────
                    BlenderMaterialFixer.fix(scene: loadedScene)
                }

                // ── 7. Bounding Box & Metadata ────────────────────────────
                let meta = Self.extractMetadata(from: loadedScene,
                                                filename: displayName,
                                                ext: "obj")
                await MainActor.run {
                    self.currentScene = loadedScene
                    self.metadata = meta
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = (error as? ModelLoaderError)?.userMessage
                        ?? error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }

    // MARK: - Helpers

    /// Recursively find the first `.obj` file inside a directory.
    nonisolated private static func findOBJ(in directory: URL, result: inout URL?, displayName: inout String) {
        guard let enumerator = FileManager.default.enumerator(atPath: directory.path) else { return }
        while let file = enumerator.nextObject() as? String {
            if (file as NSString).pathExtension.lowercased() == "obj" {
                result = directory.appendingPathComponent(file)
                displayName = (file as NSString).lastPathComponent
                return
            }
        }
    }

    /// Best-effort: copy MTL, textures, and texture subdirectories that live next to the
    /// source files but weren't explicitly selected by the user.
    nonisolated private static func copySiblingAssets(from pickerURLs: [URL],
                                          into sandboxDir: URL,
                                          accessedURLs: inout [URL]) {
        guard let first = pickerURLs.first else { return }
        let sourceDir = first.deletingLastPathComponent()

        // Try to gain access to the parent directory
        if sourceDir.startAccessingSecurityScopedResource() {
            accessedURLs.append(sourceDir)
        }

        guard let siblings = try? FileManager.default.contentsOfDirectory(
            at: sourceDir, includingPropertiesForKeys: [.isDirectoryKey]
        ) else { return }

        let textureExts: Set<String> = ["png", "jpg", "jpeg", "tga", "bmp", "tiff", "tif", "exr", "hdr"]
        let sidecarExts: Set<String> = ["mtl"]

        for sibling in siblings {
            let ext = sibling.pathExtension.lowercased()
            let dest = sandboxDir.appendingPathComponent(sibling.lastPathComponent)

            guard !FileManager.default.fileExists(atPath: dest.path) else { continue }

            if textureExts.contains(ext) || sidecarExts.contains(ext) {
                try? FileManager.default.copyItem(at: sibling, to: dest)
            } else {
                // Copy subdirectories (e.g. "textures/") that may contain images
                var isDir: ObjCBool = false
                if FileManager.default.fileExists(atPath: sibling.path, isDirectory: &isDir), isDir.boolValue {
                    try? FileManager.default.copyItem(at: sibling, to: dest)
                }
            }
        }
    }

    nonisolated private static func clearDirectory(_ dir: URL) {
        guard let files = try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: nil
        ) else { return }
        for file in files { try? FileManager.default.removeItem(at: file) }
    }

    // MARK: - Metadata Extraction

    nonisolated static func extractMetadata(from scene: SCNScene, filename: String, ext: String) -> ModelMetadata {
        var meta = ModelMetadata(filename: filename, format: ext.uppercased())

        let root = scene.rootNode
        let (minV, maxV) = root.boundingBox
        meta.boundingBoxDimensions = SCNVector3(maxV.x - minV.x,
                                                maxV.y - minV.y,
                                                maxV.z - minV.z)

        var verts = 0, tris = 0, mats = 0

        root.enumerateChildNodes { node, _ in
            guard let geom = node.geometry else { return }
            mats += geom.materials.count
            if let src = geom.sources(for: .vertex).first { verts += src.vectorCount }
            for el in geom.elements where el.primitiveType == .triangles { tris += el.primitiveCount }
        }

        meta.vertexCount = verts
        meta.triangleCount = tris
        meta.materialCount = mats
        return meta
    }
}

// MARK: - Error Type

enum ModelLoaderError: Error {
    case noOBJFound
    case loadFailed

    var userMessage: String {
        switch self {
        case .noOBJFound:
            return "No OBJ file found. Please select a folder or files containing a .obj model."
        case .loadFailed:
            return "Failed to load the 3D model. The file may be corrupted or use unsupported features."
        }
    }
}

// MARK: - Texture Resolver

/// Walks every material property in a scene and resolves unloaded texture paths
/// (strings / URLs left behind by ModelIO) into actual `UIImage` objects.
enum TextureResolver {

    private static let imageExtensions: Set<String> = [
        "png", "jpg", "jpeg", "tga", "bmp", "tiff", "tif", "exr", "hdr"
    ]

    @MainActor
    static func resolve(in scene: SCNScene, searchDirectories: [URL]) {
        // Build a fast lookup: lowercased-filename → URL for every image in the search dirs
        var lookup: [String: URL] = [:]
        for dir in searchDirectories {
            guard let enumerator = FileManager.default.enumerator(
                at: dir, includingPropertiesForKeys: nil
            ) else { continue }
            while let fileURL = enumerator.nextObject() as? URL {
                if imageExtensions.contains(fileURL.pathExtension.lowercased()) {
                    lookup[fileURL.lastPathComponent.lowercased()] = fileURL
                }
            }
        }

        scene.rootNode.enumerateChildNodes { node, _ in
            guard let geom = node.geometry else { return }
            for mat in geom.materials {
                resolveProperty(mat.diffuse,          lookup: lookup, dirs: searchDirectories)
                resolveProperty(mat.normal,           lookup: lookup, dirs: searchDirectories)
                resolveProperty(mat.specular,         lookup: lookup, dirs: searchDirectories)
                resolveProperty(mat.roughness,        lookup: lookup, dirs: searchDirectories)
                resolveProperty(mat.metalness,        lookup: lookup, dirs: searchDirectories)
                resolveProperty(mat.ambientOcclusion, lookup: lookup, dirs: searchDirectories)
                resolveProperty(mat.emission,         lookup: lookup, dirs: searchDirectories)
            }
        }
    }

    @MainActor
    private static func resolveProperty(_ prop: SCNMaterialProperty,
                                         lookup: [String: URL],
                                         dirs: [URL]) {
        // Already a loaded image — nothing to do.
        if prop.contents is UIImage { return }

        // Extract a path hint from whatever ModelIO stored in .contents
        let pathHint: String? = {
            if let s = prop.contents as? String   { return s }
            if let s = prop.contents as? NSString { return s as String }
            if let u = prop.contents as? URL {
                // URL that already points to a valid file?
                if FileManager.default.fileExists(atPath: u.path),
                   let img = UIImage(contentsOfFile: u.path) {
                    prop.contents = img
                    return nil                    // resolved — nothing more to do
                }
                return u.path
            }
            return nil
        }()
        guard let hint = pathHint else { return }

        let filename = (hint as NSString).lastPathComponent.lowercased()

        // 1) Fast lookup by filename
        if let url = lookup[filename], let img = UIImage(contentsOfFile: url.path) {
            prop.contents = img
            return
        }

        // 2) Try the full relative path against each search directory
        for dir in dirs {
            let fullURL = dir.appendingPathComponent(hint)
            if FileManager.default.fileExists(atPath: fullURL.path),
               let img = UIImage(contentsOfFile: fullURL.path) {
                prop.contents = img
                return
            }
        }
    }
}

// MARK: - Blender Material Fixer

/// Corrects common material artifacts produced by Blender's OBJ / MTL exporter
/// (overpowering ambient, phantom emission, missing transparency, wrong lighting model).
enum BlenderMaterialFixer {

    @MainActor
    static func fix(scene: SCNScene) {
        scene.rootNode.enumerateChildNodes { node, _ in
            node.castsShadow = true
            guard let geom = node.geometry else { return }
            for mat in geom.materials { fixMaterial(mat) }
        }
    }

    @MainActor
    private static func fixMaterial(_ mat: SCNMaterial) {
        mat.isDoubleSided = true

        // ── Transparency ────────────────────────────────────────────
        // Blender sometimes writes d 0.0 (fully transparent) when it means opaque.
        if mat.transparency == 0.0 {
            mat.transparency = 1.0
        }

        // ── Ambient (Ka) ────────────────────────────────────────────
        // Blender defaults to Ka 1 1 1 — makes models glow white.
        if let c = mat.ambient.contents as? UIColor, Self.isNearWhite(c) {
            mat.ambient.contents = UIColor(white: 0.15, alpha: 1.0)
        } else if mat.ambient.contents == nil {
            mat.ambient.contents = UIColor(white: 0.15, alpha: 1.0)
        }

        // ── Emission (Ke) ───────────────────────────────────────────
        // Blender can write Ke 1 1 1 which makes everything self-illuminated.
        if let c = mat.emission.contents as? UIColor, Self.isBright(c),
           !(mat.emission.contents is UIImage) {
            mat.emission.contents = UIColor.black
        }

        // ── Lighting model ──────────────────────────────────────────
        // OBJ/MTL is not truly PBR. If ModelIO tagged the material as physicallyBased
        // but there are no metalness/roughness *maps*, switch to Blinn so the 3-point
        // directional lights actually produce visible shading.
        if mat.lightingModel == .physicallyBased {
            let hasPBRMaps = (mat.metalness.contents is UIImage)
                          || (mat.roughness.contents is UIImage)
            if !hasPBRMaps {
                mat.lightingModel = .blinn
                if mat.specular.contents == nil {
                    mat.specular.contents = UIColor(white: 0.3, alpha: 1.0)
                }
                mat.shininess = 30.0
            }
        }

        // ── Texture wrapping ────────────────────────────────────────
        if mat.diffuse.contents is UIImage {
            mat.diffuse.wrapS = .repeat
            mat.diffuse.wrapT = .repeat
        }
        if mat.normal.contents is UIImage {
            mat.normal.wrapS = .repeat
            mat.normal.wrapT = .repeat
        }
    }

    // MARK: Private Color Helpers

    @MainActor
    private static func isNearWhite(_ color: UIColor) -> Bool {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0
        color.getRed(&r, green: &g, blue: &b, alpha: nil)
        return r > 0.8 && g > 0.8 && b > 0.8
    }

    @MainActor
    private static func isBright(_ color: UIColor) -> Bool {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0
        color.getRed(&r, green: &g, blue: &b, alpha: nil)
        return r > 0.5 && g > 0.5 && b > 0.5
    }
}
