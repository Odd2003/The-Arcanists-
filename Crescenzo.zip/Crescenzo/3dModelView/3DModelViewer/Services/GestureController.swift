import UIKit
import SceneKit

/// Manages all gesture recognizers attached to the SCNView:
/// one-finger orbit with inertia, pinch-to-dolly zoom, two-finger pan, and double-tap reset.
final class GestureController: NSObject, UIGestureRecognizerDelegate {

    // MARK: - References

    private weak var scnView: SCNView?
    private weak var pivotNode: SCNNode?
    private weak var cameraNode: SCNNode?

    // MARK: - Inertia

    private var velocity: CGPoint = .zero
    private var displayLink: CADisplayLink?

    // MARK: - Gesture Tracking State

    private var lastPanLocation: CGPoint = .zero
    private var lastZoomScale: CGFloat = 1.0
    private var lastTwoFingerLocation: CGPoint = .zero

    // MARK: - Zoom Limits

    private let defaultCameraZ: Float
    private let minZoom: Float
    private let maxZoom: Float

    // MARK: - Init

    init(scnView: SCNView, pivotNode: SCNNode, cameraNode: SCNNode, boundingBoxSize: Float) {
        self.scnView = scnView
        self.pivotNode = pivotNode
        self.cameraNode = cameraNode

        self.defaultCameraZ = boundingBoxSize * 1.5
        self.minZoom = boundingBoxSize * 0.15
        self.maxZoom = boundingBoxSize * 5.0

        super.init()
        setupGestureRecognizers()
    }

    // MARK: - Setup

    private func setupGestureRecognizers() {
        guard let view = scnView else { return }

        // 1-finger orbit
        let orbitPan = UIPanGestureRecognizer(target: self, action: #selector(handleOrbit(_:)))
        orbitPan.minimumNumberOfTouches = 1
        orbitPan.maximumNumberOfTouches = 1
        orbitPan.delegate = self
        view.addGestureRecognizer(orbitPan)

        // Pinch-to-zoom (dolly)
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(handleZoom(_:)))
        pinch.delegate = self
        view.addGestureRecognizer(pinch)

        // 2-finger pan / translate
        let translatePan = UIPanGestureRecognizer(target: self, action: #selector(handleTranslate(_:)))
        translatePan.minimumNumberOfTouches = 2
        translatePan.maximumNumberOfTouches = 2
        translatePan.delegate = self
        view.addGestureRecognizer(translatePan)

        // Double-tap reset
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        view.addGestureRecognizer(doubleTap)
    }

    // MARK: - Orbit (1 Finger)

    @objc private func handleOrbit(_ gesture: UIPanGestureRecognizer) {
        guard gesture.numberOfTouches == 1 else { return }
        guard let view = scnView else { return }

        let location = gesture.location(in: view)

        switch gesture.state {
        case .began:
            lastPanLocation = location
            stopInertia()
        case .changed:
            let deltaX = Float(location.x - lastPanLocation.x)
            let deltaY = Float(location.y - lastPanLocation.y)
            lastPanLocation = location
            applyRotation(deltaX: deltaX, deltaY: deltaY)
            velocity = gesture.velocity(in: view)
        case .ended, .cancelled:
            startInertia()
        default:
            break
        }
    }

    // MARK: - Zoom (Pinch)

    @objc private func handleZoom(_ gesture: UIPinchGestureRecognizer) {
        guard let cameraNode = cameraNode else { return }

        switch gesture.state {
        case .began:
            lastZoomScale = gesture.scale
        case .changed:
            let delta = Float(gesture.scale - lastZoomScale)
            lastZoomScale = gesture.scale

            let sensitivity: Float = (maxZoom - minZoom) * 0.2
            var z = cameraNode.position.z - delta * sensitivity
            z = max(minZoom, min(z, maxZoom))
            cameraNode.position.z = z
        default:
            break
        }
    }

    // MARK: - Translate (2 Fingers)

    @objc private func handleTranslate(_ gesture: UIPanGestureRecognizer) {
        guard gesture.numberOfTouches == 2 else { return }
        guard let view = scnView, let pivotNode = pivotNode, let cameraNode = cameraNode else { return }

        let location = gesture.location(in: view)

        switch gesture.state {
        case .began:
            lastTwoFingerLocation = location
        case .changed:
            let dx = Float(location.x - lastTwoFingerLocation.x)
            let dy = Float(location.y - lastTwoFingerLocation.y)
            lastTwoFingerLocation = location

            let depthScale = max(1.0, cameraNode.position.z) * 0.002
            pivotNode.localTranslate(by: SCNVector3(dx * depthScale, -dy * depthScale, 0))
        default:
            break
        }
    }

    // MARK: - Double-Tap Reset

    @objc private func handleDoubleTap(_ gesture: UITapGestureRecognizer) {
        guard let pivotNode = pivotNode, let cameraNode = cameraNode else { return }

        SCNTransaction.begin()
        SCNTransaction.animationDuration = 0.5
        SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: .easeInEaseOut)

        pivotNode.position = SCNVector3Zero
        pivotNode.eulerAngles = SCNVector3Zero
        cameraNode.position = SCNVector3(0, 0, defaultCameraZ)

        SCNTransaction.commit()
    }

    // MARK: - Rotation Math

    private func applyRotation(deltaX: Float, deltaY: Float) {
        guard let pivotNode = pivotNode else { return }

        let sensitivity: Float = 0.008

        let yaw   = -deltaX * sensitivity
        let pitch = -deltaY * sensitivity

        let yawRot   = SCNMatrix4MakeRotation(yaw, 0, 1, 0)
        let pitchRot = SCNMatrix4MakeRotation(pitch, 1, 0, 0)

        pivotNode.transform = SCNMatrix4Mult(SCNMatrix4Mult(pitchRot, pivotNode.transform), yawRot)
    }

    // MARK: - Inertia

    private func startInertia() {
        stopInertia()
        guard abs(velocity.x) > 100 || abs(velocity.y) > 100 else { return }

        displayLink = CADisplayLink(target: self, selector: #selector(updateInertia))
        displayLink?.add(to: .main, forMode: .common)
    }

    private func stopInertia() {
        displayLink?.invalidate()
        displayLink = nil
    }

    @objc private func updateInertia() {
        let decay: CGFloat = 0.92
        velocity.x *= decay
        velocity.y *= decay

        if abs(velocity.x) < 5 && abs(velocity.y) < 5 {
            stopInertia()
            return
        }

        applyRotation(deltaX: Float(velocity.x * 0.016),
                       deltaY: Float(velocity.y * 0.016))
    }

    // MARK: - UIGestureRecognizerDelegate

    func gestureRecognizer(
        _ gestureRecognizer: UIGestureRecognizer,
        shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer
    ) -> Bool {
        true
    }
}
