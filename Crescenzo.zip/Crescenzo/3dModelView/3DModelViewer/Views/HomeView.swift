import SwiftUI
import UniformTypeIdentifiers

struct HomeView: View {

    @StateObject private var loader = ModelLoader()
    @State private var showDocumentPicker = false
    @State private var navigateToViewer = false
    @State private var showError = false

    // Subtle icon float animation
    @State private var iconOffset: CGFloat = 0

    var body: some View {
        NavigationStack {
            ZStack {
                // ── Background ──────────────────────────────
                backgroundGradient

                VStack(spacing: 0) {
                    Spacer()

                    // ── Hero Icon ────────────────────────────
                    heroIcon
                        .padding(.bottom, 28)

                    // ── Title Block ──────────────────────────
                    titleBlock
                        .padding(.bottom, 40)

                    // ── Import Button ────────────────────────
                    importButton
                        .padding(.bottom, 16)

                    // ── Supported Formats Tag ────────────────
                    Text("Supports OBJ + MTL")
                        .font(.footnote)
                        .foregroundStyle(.secondary)

                    Spacer()
                    Spacer()
                }
                .padding(.horizontal, 32)
            }
            .sheet(isPresented: $showDocumentPicker) {
                DocumentPickerView(
                    supportedTypes: UTType.supported3DModels,
                    onPick: { urls in loader.loadModel(from: urls) },
                    onDismiss: { showDocumentPicker = false }
                )
            }
            .onChange(of: loader.currentScene) { _, scene in
                if scene != nil { navigateToViewer = true }
            }
            .onChange(of: loader.errorMessage) { _, msg in
                if msg != nil { showError = true }
            }
            .fullScreenCover(isPresented: $navigateToViewer) {
                if let scene = loader.currentScene, let metadata = loader.metadata {
                    ModelViewerView(scene: scene, metadata: metadata) {
                        navigateToViewer = false
                        loader.currentScene = nil
                        loader.metadata = nil
                    }
                }
            }
            .overlay { LoadingOverlay(isLoading: loader.isLoading) }
            .alert("Import Error",
                   isPresented: $showError,
                   actions: { Button("OK") { loader.errorMessage = nil } },
                   message: { Text(loader.errorMessage ?? "") })
        }
    }

    // MARK: - Subviews

    private var backgroundGradient: some View {
        LinearGradient(
            colors: [
                Color(red: 0.07, green: 0.07, blue: 0.12),
                Color(red: 0.04, green: 0.04, blue: 0.08)
            ],
            startPoint: .top,
            endPoint: .bottom
        )
        .ignoresSafeArea()
    }

    private var heroIcon: some View {
        Image(systemName: "cube.transparent")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 90, height: 90)
            .fontWeight(.thin)
            .foregroundStyle(
                LinearGradient(colors: [.indigo, .cyan],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
            )
            .shadow(color: .indigo.opacity(0.4), radius: 24, y: 8)
            .offset(y: iconOffset)
            .onAppear {
                withAnimation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true)) {
                    iconOffset = -8
                }
            }
    }

    private var titleBlock: some View {
        VStack(spacing: 10) {
            Text("3D Model Viewer")
                .font(.system(size: 32, weight: .bold, design: .rounded))
                .foregroundStyle(.white)

            Text("Import and inspect OBJ models\nexported from Blender.")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.55))
                .lineSpacing(3)
        }
    }

    private var importButton: some View {
        Button {
            showDocumentPicker = true
        } label: {
            Label("Import Model", systemImage: "square.and.arrow.down")
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(
                    LinearGradient(colors: [.indigo, .indigo.opacity(0.7)],
                                   startPoint: .leading,
                                   endPoint: .trailing)
                )
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .shadow(color: .indigo.opacity(0.35), radius: 12, y: 6)
        }
        .sensoryFeedback(.impact(flexibility: .soft), trigger: showDocumentPicker)
    }
}

#Preview {
    HomeView()
}
