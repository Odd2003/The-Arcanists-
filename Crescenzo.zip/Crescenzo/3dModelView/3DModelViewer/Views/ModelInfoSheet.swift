import SwiftUI
import SceneKit

struct ModelInfoSheet: View {
    var metadata: ModelMetadata
    var onDismiss: () -> Void

    var body: some View {
        NavigationStack {
            List {
                Section {
                    row(icon: "doc.fill", label: "Name", value: metadata.filename)
                    row(icon: "cube.fill", label: "Format", value: metadata.format)
                } header: {
                    Text("File")
                }

                Section {
                    row(icon: "point.3.filled.connected.trianglepath.dotted",
                        label: "Vertices",
                        value: metadata.formattedVertexCount)
                    row(icon: "triangle.fill",
                        label: "Triangles",
                        value: metadata.formattedTriangleCount)
                } header: {
                    Text("Geometry")
                }

                Section {
                    row(icon: "paintpalette.fill",
                        label: "Materials",
                        value: "\(metadata.materialCount)")
                } header: {
                    Text("Materials")
                }

                Section {
                    row(icon: "arrow.left.and.right",
                        label: "Width (X)",
                        value: String(format: "%.2f", metadata.boundingBoxDimensions.x))
                    row(icon: "arrow.up.and.down",
                        label: "Height (Y)",
                        value: String(format: "%.2f", metadata.boundingBoxDimensions.y))
                    row(icon: "arrow.forward.and.line.horizontal.and.arrow.backward",
                        label: "Depth (Z)",
                        value: String(format: "%.2f", metadata.boundingBoxDimensions.z))
                } header: {
                    Text("Bounding Box (Scene Units)")
                }
            }
            .navigationTitle("Model Info")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done", action: onDismiss)
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }

    // MARK: - Row Helper

    private func row(icon: String, label: String, value: String) -> some View {
        HStack {
            Label(label, systemImage: icon)
                .foregroundStyle(.primary)
            Spacer()
            Text(value)
                .foregroundStyle(.secondary)
                .monospacedDigit()
        }
    }
}
