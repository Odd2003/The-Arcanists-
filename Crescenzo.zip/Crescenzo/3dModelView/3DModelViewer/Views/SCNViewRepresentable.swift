import SwiftUI
import SceneKit
import ModelIO

struct SCNViewRepresentable: UIViewRepresentable {
    var scene: SCNScene
    var boundingBoxSize: Float
    var showMaterials: Bool = true
    var moveLightsWithModel: Bool = false

    func makeCoordinator() -> Coordinator { Coordinator() }

    // MARK: - Create

    func makeUIView(context: Context) -> SCNView {
        let scnView = SCNView(frame: .zero)

        // Rendering quality
        scnView.antialiasingMode = .multisampling4X
        scnView.preferredFramesPerSecond = 120      // ProMotion
        scnView.isJitteringEnabled = false
        scnView.autoenablesDefaultLighting = false   // We supply our own lights
        scnView.backgroundColor = UIColor(red: 0.11, green: 0.11, blue: 0.118, alpha: 1) // #1C1C1E

        scnView.scene = context.coordinator.setupEnvironment(
            for: scene,
            boundingBoxSize: boundingBoxSize,
            in: scnView
        )

        return scnView
    }

    // MARK: - Update (Material Toggle)

    func updateUIView(_ scnView: SCNView, context: Context) {
        let coord = context.coordinator

        // Update lighting attachment
        coord.updateLightingAttachment(moveWithModel: moveLightsWithModel)

        scnView.scene?.rootNode.enumerateChildNodes { node, _ in
            guard let geometry = node.geometry else { return }

            // Cache original materials on first encounter
            if coord.originalMaterials[geometry] == nil {
                coord.originalMaterials[geometry] = geometry.materials
            }

            if showMaterials {
                if let originals = coord.originalMaterials[geometry] {
                    geometry.materials = originals
                }
            } else {
                let clay = SCNMaterial()
                clay.diffuse.contents = UIColor(white: 0.78, alpha: 1)
                clay.lightingModel = .blinn
                clay.isDoubleSided = true
                clay.shininess = 20
                geometry.materials = Array(repeating: clay, count: geometry.materials.count)
            }
        }
    }

    // MARK: - Coordinator

    final class Coordinator: NSObject {
        var gestureController: GestureController?
        var originalMaterials: [SCNGeometry: [SCNMaterial]] = [:]
        var lightingNodes: [SCNNode] = []
        var lightWrapper: SCNNode?
        var pivotWrapper: SCNNode?
        var sceneRoot: SCNNode?

        func setupEnvironment(for scene: SCNScene,
                              boundingBoxSize: Float,
                              in scnView: SCNView) -> SCNScene {
            self.sceneRoot = scene.rootNode

            // Prevent duplicating setup if view is recreated
            if let existingPivot = scene.rootNode.childNode(withName: "pivotWrapper", recursively: false) {
                self.pivotWrapper = existingPivot
                self.lightWrapper = scene.rootNode.childNode(withName: "lightWrapper", recursively: false)
                
                // Get existing camera
                let cameraNode = scene.rootNode.childNode(withName: "cameraNode", recursively: false)!
                
                gestureController = GestureController(
                    scnView: scnView,
                    pivotNode: existingPivot,
                    cameraNode: cameraNode,
                    boundingBoxSize: boundingBoxSize
                )
                return scene
            }

            // ── 1. Pivot wrapper ─────────────────────────────────
            let pivotWrapper = SCNNode()
            pivotWrapper.name = "pivotWrapper"
            let existingNodes = scene.rootNode.childNodes
            for node in existingNodes { pivotWrapper.addChildNode(node) }
            scene.rootNode.addChildNode(pivotWrapper)
            self.pivotWrapper = pivotWrapper

            // Center the model on its geometric midpoint
            let (minBB, maxBB) = pivotWrapper.boundingBox
            let center = SCNVector3(
                (minBB.x + maxBB.x) / 2,
                (minBB.y + maxBB.y) / 2,
                (minBB.z + maxBB.z) / 2
            )
            pivotWrapper.pivot = SCNMatrix4MakeTranslation(center.x, center.y, center.z)

            // ── 2. Camera ────────────────────────────────────────
            let cameraNode = SCNNode()
            cameraNode.name = "cameraNode"
            let camera = SCNCamera()
            camera.fieldOfView = 60
            camera.zNear  = Double(max(boundingBoxSize * 0.01, 0.01))
            camera.zFar   = Double(boundingBoxSize * 50)
            cameraNode.camera = camera

            let cameraDistance = boundingBoxSize * 1.5
            cameraNode.position = SCNVector3(0, 0, cameraDistance)
            scene.rootNode.addChildNode(cameraNode)

            // ── 3. Three-point lighting ──────────────────────────
            let lightContainer = SCNNode()
            lightContainer.name = "lightWrapper"
            scene.rootNode.addChildNode(lightContainer)
            self.lightWrapper = lightContainer
            
            addLighting(to: lightContainer, size: boundingBoxSize)

            // ── 4. Environment for PBR reflections ───────────────
            let sky = MDLSkyCubeTexture(
                name: "sky",
                channelEncoding: .float16,
                textureDimensions: vector_int2(128, 128),
                turbidity: 0.5,
                sunElevation: 0.6,
                upperAtmosphereScattering: 0.15,
                groundAlbedo: 0.85
            )
            scene.lightingEnvironment.contents = sky
            scene.lightingEnvironment.intensity = 1.0

            // ── 5. Gestures ──────────────────────────────────────
            gestureController = GestureController(
                scnView: scnView,
                pivotNode: pivotWrapper,
                cameraNode: cameraNode,
                boundingBoxSize: boundingBoxSize
            )

            return scene
        }

        func updateLightingAttachment(moveWithModel: Bool) {
            guard let lightContainer = lightWrapper else { return }
            
            if moveWithModel {
                // Auto-orbit the lights around the model
                let orbit = SCNAction.rotateBy(x: 0, y: CGFloat.pi * 2, z: 0, duration: 8.0)
                let repeatOrbit = SCNAction.repeatForever(orbit)
                lightContainer.runAction(repeatOrbit, forKey: "lightOrbitAnimation")
            } else {
                // Stop the orbit and reset rotation
                lightContainer.removeAction(forKey: "lightOrbitAnimation")
                let reset = SCNAction.rotateTo(x: 0, y: 0, z: 0, duration: 0.3)
                lightContainer.runAction(reset)
            }
        }

        // MARK: - Lighting

        private func addLighting(to parentNode: SCNNode, size: Float) {
            // Ambient fill
            let ambient = SCNNode()
            ambient.name = "customLight"
            ambient.light = {
                let l = SCNLight()
                l.type = .ambient
                l.intensity = 300
                l.color = UIColor(white: 0.95, alpha: 1)
                return l
            }()
            parentNode.addChildNode(ambient)
            lightingNodes.append(ambient)

            // Key light (directional, upper-left)
            let key = SCNNode()
            key.name = "customLight"
            key.light = {
                let l = SCNLight()
                l.type = .directional
                l.intensity = 1000
                l.castsShadow = true
                l.shadowRadius = 4
                l.shadowSampleCount = 8
                return l
            }()
            key.position = SCNVector3(-size, size, size)
            key.look(at: SCNVector3Zero)
            parentNode.addChildNode(key)
            lightingNodes.append(key)

            // Fill light (softer, opposite side)
            let fill = SCNNode()
            fill.name = "customLight"
            fill.light = {
                let l = SCNLight()
                l.type = .omni
                l.intensity = 500
                return l
            }()
            fill.position = SCNVector3(size * 0.8, size * 0.2, -size * 0.6)
            parentNode.addChildNode(fill)
            lightingNodes.append(fill)

            // Rim / back light for edge definition
            let rim = SCNNode()
            rim.name = "customLight"
            rim.light = {
                let l = SCNLight()
                l.type = .omni
                l.intensity = 250
                return l
            }()
            rim.position = SCNVector3(0, -size * 0.5, -size)
            parentNode.addChildNode(rim)
            lightingNodes.append(rim)
        }
    }
}
