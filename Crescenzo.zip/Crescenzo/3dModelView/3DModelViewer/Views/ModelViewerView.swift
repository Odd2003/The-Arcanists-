import SwiftUI
import SceneKit

// MARK: - Model Viewer

struct ModelViewerView: View {
    var scene: SCNScene
    var metadata: ModelMetadata
    var onDismiss: () -> Void

    @State private var showInfo = false
    @State private var showMaterials = false
    @State private var moveLightsWithModel = false
    @State private var resetTrigger = UUID()

    var body: some View {
        ZStack {
            // 3D viewport — keyed so toolbar reset rebuilds the scene
            SCNViewRepresentable(
                scene: scene,
                boundingBoxSize: max(
                    metadata.boundingBoxDimensions.x,
                    metadata.boundingBoxDimensions.y,
                    metadata.boundingBoxDimensions.z
                ),
                showMaterials: showMaterials,
                moveLightsWithModel: moveLightsWithModel
            )
            .id(resetTrigger)
            .ignoresSafeArea()

            // HUD
            ViewerToolbar(
                filename: metadata.filename,
                onDismiss: onDismiss,
                showInfo: $showInfo,
                showMaterials: $showMaterials,
                moveLightsWithModel: $moveLightsWithModel,
                resetTrigger: $resetTrigger
            )
        }
        .sheet(isPresented: $showInfo) {
            ModelInfoSheet(metadata: metadata) { showInfo = false }
        }
        .statusBarHidden()
    }
}

// MARK: - Toolbar Overlay

private struct ViewerToolbar: View {
    let filename: String
    var onDismiss: () -> Void

    @Binding var showInfo: Bool
    @Binding var showMaterials: Bool
    @Binding var moveLightsWithModel: Bool
    @Binding var resetTrigger: UUID

    var body: some View {
        VStack(spacing: 0) {
            // ── Top bar ──────────────────────────────────────
            HStack(spacing: 12) {
                toolbarButton(icon: "xmark", action: onDismiss)

                Spacer()

                // Filename pill
                Text(filename)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 7)
                    .background(.ultraThinMaterial, in: Capsule())

                Spacer()

                toolbarButton(icon: "info", action: { showInfo = true })
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)

            Spacer()

            // ── Bottom bar ───────────────────────────────────
            HStack(spacing: 16) {
                Spacer()

                // Light Movement toggle
                toolbarButton(
                    icon: moveLightsWithModel
                        ? "lightbulb.fill"
                        : "lightbulb",
                    action: { moveLightsWithModel.toggle() }
                )

                // Material toggle
                toolbarButton(
                    icon: showMaterials
                        ? "paintbrush.fill"
                        : "paintbrush",
                    action: { showMaterials.toggle() }
                )

                // Reset
                toolbarButton(
                    icon: "arrow.counterclockwise",
                    action: { resetTrigger = UUID() }
                )
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 16)
        }
    }

    private func toolbarButton(icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 40, height: 40)
                .background(.ultraThinMaterial, in: Circle())
        }
    }
}
