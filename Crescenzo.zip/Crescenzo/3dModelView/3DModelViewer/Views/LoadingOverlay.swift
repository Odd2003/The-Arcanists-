import SwiftUI

struct LoadingOverlay: View {
    var isLoading: Bool

    @State private var pulse = false

    var body: some View {
        if isLoading {
            ZStack {
                Color.black.opacity(0.55)
                    .ignoresSafeArea()

                VStack(spacing: 18) {
                    ProgressView()
                        .controlSize(.large)
                        .tint(.white)

                    Text("Loading Model…")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.white.opacity(pulse ? 1 : 0.6))
                        .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true),
                                   value: pulse)
                }
                .padding(32)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            }
            .onAppear { pulse = true }
            .transition(.opacity)
        }
    }
}
