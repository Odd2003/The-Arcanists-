import SceneKit
import ObjectiveC
class MySource: SCNSceneSource {
    override init() {
        super.init()
    }
}
do {
    let source = MySource()
    print("allocated")
}
print("test dealloc")
