import re

with open('3DModelViewer.xcodeproj/project.pbxproj', 'r') as f:
    content = f.read()

content = content.replace("3DModelViewer/Info.plist;", "CustomInfo.plist;")

with open('3DModelViewer.xcodeproj/project.pbxproj', 'w') as f:
    f.write(content)
