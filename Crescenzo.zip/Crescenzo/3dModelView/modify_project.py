import re

with open('3DModelViewer.xcodeproj/project.pbxproj', 'r') as f:
    content = f.read()

content = re.sub(
    r'(GENERATE_INFOPLIST_FILE = YES;)',
    r'\1\n\t\t\t\tINFOPLIST_FILE = "3DModelViewer/Info.plist";',
    content
)

with open('3DModelViewer.xcodeproj/project.pbxproj', 'w') as f:
    f.write(content)
