import Foundation
import SceneKit
import GLTFSceneKit

let url = URL(fileURLWithPath: "/tmp/test.glb")
let source = GLTFSceneSource(url: url)
print("done")
